package com.tk2017b.kelompok3.linear;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btn_v = findViewById(R.id.btn_v);
        Button btn_h = findViewById(R.id.btn_h);
        btn_v.setOnClickListener(this);
        btn_h.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_v:
                Intent moveIntent = new Intent(MainActivity.this, MoveActivity.class);
                startActivity(moveIntent);
                break;
        }
        switch (v.getId()){
            case R.id.btn_h:
                Intent moveIntent = new Intent(MainActivity.this, MoveActivity2.class);
                startActivity(moveIntent);
                break;
        }
    }
}
